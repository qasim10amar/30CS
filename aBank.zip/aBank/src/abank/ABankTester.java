

package abank;

import java.util.Scanner;


public class ABankTester 
{
   public static void main( String[] args )
    {
        Scanner s = new Scanner(System.in); 
        
       
        
        ABank bank = new ABank();
        
        System.out.println(bank.getBalance());
        bank.setBalance(25);
        System.out.println(bank.getBalance());
        
        
        System.out.println("How much money do you want to deposit? ");
        double input = s.nextDouble();
        bank.Deposit(input);
        
        bank.withDraw(75);
        
        System.out.println("Your balance is: "+ bank.getBalance());
        
        
     }
}
