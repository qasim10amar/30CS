package abank;


import java.util.Scanner;



public class ABank
{ 
  private double balance;
  private String bankName;
    
  public ABank() //Constructor
  {
     balance = 0.0;
  }
	
   
    
    
    public void withDraw(double b)
    {
       if(balance >= b) 
       {
            balance = balance - b;
       }
        
      else
       {
           System.out.println("Insufficient funds");
       }
    }
    
    public double getBalance()
    {
        return balance;
    }
    
    public void setBalance(double d)
    {
        balance = d;
    }
    
    public String getName()
    {
        return bankName;
    }
    public void setName(String s)
    {
        bankName = s;
    }
    
    public void Deposit(double b)
    {
       balance = balance + b;
       
    }
    
    
      
    
     
	
}